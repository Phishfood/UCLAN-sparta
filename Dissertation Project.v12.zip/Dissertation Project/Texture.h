#pragma once
class CTexture
{
public:
	CTexture(void);
	~CTexture(void);
};

