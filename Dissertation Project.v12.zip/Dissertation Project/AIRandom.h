#pragma once
class CAIRandom
{
public:
	CAIRandom(void);
	~CAIRandom(void);
};

