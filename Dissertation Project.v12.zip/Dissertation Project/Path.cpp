#include "Path.h"


Path::Path(void)
{
}


Path::~Path(void)
{
}
