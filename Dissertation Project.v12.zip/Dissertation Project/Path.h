#pragma once
class Path
{
public:
	Path(void);
	~Path(void);
};

