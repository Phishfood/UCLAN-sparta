#include "Texture.h"


CTexture::CTexture(void)
{
}


CTexture::~CTexture(void)
{
}
