#include "AIInterface.h"


CAIInterface::CAIInterface(void)
{
}


CAIInterface::~CAIInterface(void)
{
}
