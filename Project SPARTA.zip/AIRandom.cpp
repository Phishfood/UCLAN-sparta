#include "AIRandom.h"


CAIRandom::CAIRandom(void)
{
}


CAIRandom::~CAIRandom(void)
{
}
