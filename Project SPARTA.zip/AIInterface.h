#pragma once
class CAIInterface
{
public:
	CAIInterface(void);
	~CAIInterface(void);
};

